package test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import cars.Car;
import cars.CrashedCar;
import cars.UsedCar;

public class TestCars {

	@Test
	public void testPriceCrashedCar() {
		
		// anstelle CrashedCar.DMG_LVL_LOW auch 0 ok
		CrashedCar cc = new CrashedCar("BMW M3", 40000, CrashedCar.DMG_LVL_LOW);
		assertEquals(40000*0.9, cc.getPrice(), 0.0001);
		
		cc.setDamageLevel(CrashedCar.DMG_LVL_MEDIUM);
		assertEquals(40000*0.5, cc.getPrice(), 0.0001);
		
		cc.setDamageLevel(CrashedCar.DMG_LVL_HIGH);
		assertEquals(40000*0.1, cc.getPrice(), 0.0001);
		
		cc.setDamageLevel(CrashedCar.DMG_LVL_TOTAL);
		assertEquals(0, cc.getPrice(), 0.0001);
		
		
	}
	
	@Test
	public void testPriceUsedCar() {
		double price = 80000;
		UsedCar uc = new UsedCar("Audi A6", price, 0);
		assertEquals(price, uc.getPrice(), 0.0001);
		
		uc.setMileage(9999);
		assertEquals(price, uc.getPrice(), 0.0001);
		
		uc.setMileage(10000);
		assertEquals(price*0.95, uc.getPrice(), 0.0001);
		
		uc.setMileage(10001);
		assertEquals(price*0.95, uc.getPrice(), 0.0001);
		
		uc.setMileage(199999);
		assertEquals(price*0.05, uc.getPrice(), 0.0001);
		
		uc.setMileage(200000);
		assertEquals(0, uc.getPrice(), 0.0001);
		
		uc.setMileage(210000);
		assertEquals(0, uc.getPrice(), 0.0001);
		
	}

}
