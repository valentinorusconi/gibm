<p>Wir werden Ihnen eine E-Mail an die im Profil angegebene Adresse schicken, um das Passwort zurückzusetzen.</p>
	
<div class="row">
	<div class="col-lg-12">
		<label for="fusername" class="sr-only">Benutzername</label>
		<input type="text" id="changePassUsername" name="changePassUsername" class="form-control" placeholder="Benutzername" required autofocus><br/>
		<button class="btn btn-lg btn-primary btn-block" name="changePassUser" id="changePassUser" type="submit">Passwort ändern</button>
	</div>			
</div>
<br/>
<p>Oder doch <a id="gotoLogin" href="index.php">Einloggen</a>?</p>