<p>Sie haben eine E-Mail an die Adresse <?php //echo $_GET['mail']; ?> erhalten. Bitte finden Sie in dieser Mail den Zugangscode und fügen Sie ihn hier ein:</p>
<div class="row">
	<div class="col-lg-12">
		<label for="fusername" class="sr-only"><b>Code</b></label>
		<input type="text" id="changePassCode" name="changePassCode" class="form-control" placeholder="Code" required autofocus><br/>
		<button class="btn btn-lg btn-primary btn-block" name="changePassCodeButton" id="changePassCodeButton" type="submit">Code prüfen</button>
	</div>			
</div>
	