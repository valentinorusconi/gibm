import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ToDoList extends JFrame implements ActionListener {

	JList toDoList;
	JButton addButton;
	JButton removeButton;
	JTextField subjectTextField;
	JPanel buttonPanel;
	JPanel bottomPanel;
	DefaultListModel listModel;

	public ToDoList() {

		toDoList = new JList();
		addButton = new JButton("add");
		removeButton = new JButton("remove");
		subjectTextField = new JTextField();
		listModel = new DefaultListModel();

		toDoList.setModel(listModel);

		buttonPanel = new JPanel();
		bottomPanel = new JPanel();

		setLayout(new BorderLayout());

		buttonPanel.setLayout(new GridLayout(0, 2));
		bottomPanel.setLayout(new GridLayout(2, 0));

		bottomPanel.add(buttonPanel);
		bottomPanel.add(subjectTextField);

		buttonPanel.add(addButton);
		buttonPanel.add(removeButton);

		add(toDoList, BorderLayout.CENTER);
		add(bottomPanel, BorderLayout.SOUTH);

		addButton.addActionListener(this);
		removeButton.addActionListener(this);

		setSize(300, 400);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}

	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == addButton) {
			listModel.addElement(subjectTextField.getText());
		}

		if (e.getSource() == removeButton) {
			listModel.removeElementAt(toDoList.getSelectedIndex());
		}

	}

	public static void main(String[] args) {
		ToDoList g = new ToDoList();
	}

}