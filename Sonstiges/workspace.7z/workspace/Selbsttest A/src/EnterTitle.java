import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class EnterTitle extends JFrame implements ActionListener{

	String Title;
	JPanel framePanel = new JPanel();

	JTextField text = new JTextField();
	JButton klick = new JButton("OK");

	public EnterTitle() {

		framePanel.setLayout(new GridLayout(2,1));
		framePanel.add(text);
		framePanel.add(klick);

		klick.addActionListener(this);

		add(framePanel);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle(Title);
		setSize(400,200);
		setVisible(true);

	}

	public static void main(String[] args) {

		EnterTitle gui = new EnterTitle();

	}

	public void actionPerformed(ActionEvent action) {
		if(action.getSource() == this.klick){
			Title = text.getText();
        }

	}

}
