import java.awt.*;
import javax.swing.*;

public class RadioGUIcomplicated extends JFrame{

	JPanel framePanel = new JPanel();
	JPanel buttonPanel = new JPanel();

	JLabel band = new JLabel("Band:");
	JButton fm = new JButton("FM");
	JButton mw = new JButton("mw");
	JButton lw = new JButton("lw");
	JButton scan = new JButton("Scan");

	public RadioGUIcomplicated(){

		framePanel.setLayout(new BorderLayout());
		buttonPanel.setLayout(new GridLayout(1,3));

		framePanel.add(band, BorderLayout.NORTH);
		buttonPanel.add(fm, BorderLayout.WEST);
		buttonPanel.add(mw, BorderLayout.CENTER);
		buttonPanel.add(lw, BorderLayout.EAST);
		framePanel.add(buttonPanel, BorderLayout.CENTER);
		framePanel.add(scan, BorderLayout.SOUTH);

		add(framePanel);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Radio");
		setSize(300,120);
		setVisible(true);
	}

	public static void main(String[] args) {

		RadioGUIcomplicated gui = new RadioGUIcomplicated();

	}

}
