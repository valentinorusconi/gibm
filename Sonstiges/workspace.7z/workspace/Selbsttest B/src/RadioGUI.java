import java.awt.*;
import javax.swing.*;

public class RadioGUI extends JFrame{

	JPanel framePanel = new JPanel();

	JLabel band = new JLabel("Band:");
	JButton fm = new JButton("FM");
	JButton mw = new JButton("mw");
	JButton lw = new JButton("lw");
	JButton scan = new JButton("Scan");

	public RadioGUI(){

		framePanel.setLayout(new BorderLayout());

		framePanel.add(band, BorderLayout.NORTH);
		framePanel.add(fm, BorderLayout.WEST);
		framePanel.add(mw, BorderLayout.CENTER);
		framePanel.add(lw, BorderLayout.EAST);
		framePanel.add(scan, BorderLayout.SOUTH);

		add(framePanel);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Radio");
		setSize(300,120);
		setVisible(true);
	}

	public static void main(String[] args) {

		RadioGUI gui = new RadioGUI();

	}

}
