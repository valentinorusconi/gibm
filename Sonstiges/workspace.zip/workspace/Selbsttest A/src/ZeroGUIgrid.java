import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ZeroGUIgrid extends JFrame{

	JPanel centerPanel = new JPanel();

	JPanel bottomPanel = new JPanel();

	JLabel doesNothing = new JLabel("Dieses Programm tut nichts");
	JLabel copy = new JLabel("Copyright (c) 1999");
	JLabel company = new JLabel("Zerosoft AG");

	JButton leftButton = new JButton("Abbrechen");
	JButton centerButton = new JButton("OK");
	JButton rightButton = new JButton("Hilfe");

	public ZeroGUIgrid() {

		//CENTERPANEL

		centerPanel.setLayout(new GridLayout(3,1));
		add(centerPanel,BorderLayout.CENTER);

		centerPanel.add(doesNothing);
		centerPanel.add(copy);
		centerPanel.add(company);


		//BOTTOMPANEL

		bottomPanel.setLayout(new GridLayout(1,3));
		add(bottomPanel,BorderLayout.SOUTH);

		bottomPanel.add(leftButton);
		bottomPanel.add(centerButton);
		bottomPanel.add(rightButton);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Zero");
		setSize(400,200);
		setVisible(true);
	}

	public static void main(String[] args) {

		ZeroGUIgrid gui = new ZeroGUIgrid();

	}

}
