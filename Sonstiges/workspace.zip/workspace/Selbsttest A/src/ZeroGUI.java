import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ZeroGUI extends JFrame{

	JPanel centerPanel = new JPanel();

	JPanel bottomPanel = new JPanel();

	JLabel doesNothing = new JLabel("Dieses Programm tut nichts");
	JLabel copy = new JLabel("Copyright (c) 1999");
	JLabel company = new JLabel("Zerosoft AG");

	JButton leftButton = new JButton("Abbrechen");
	JButton centerButton = new JButton("OK");
	JButton rightButton = new JButton("Hilfe");

	public ZeroGUI() {

		//CENTERPANEL
		centerPanel.setLayout(new BorderLayout(10,10));
		add(centerPanel,BorderLayout.CENTER);

		centerPanel.add(doesNothing, BorderLayout.NORTH);
		centerPanel.add(copy, BorderLayout.CENTER);
		centerPanel.add(company, BorderLayout.SOUTH);


		//BOTTOMPANEL
		bottomPanel.setLayout(new BorderLayout(10,10));
		add(bottomPanel,BorderLayout.SOUTH);

		bottomPanel.add(leftButton,BorderLayout.WEST);
		bottomPanel.add(centerButton,BorderLayout.CENTER);
		bottomPanel.add(rightButton,BorderLayout.EAST);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Zero");
		setSize(300,100);
		setVisible(true);
	}

	public static void main(String[] args) {

		ZeroGUI gui = new ZeroGUI();

	}

}
