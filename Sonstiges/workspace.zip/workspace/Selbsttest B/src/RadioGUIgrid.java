





//THAT DOES NICHT WORK









import java.awt.*;
import javax.swing.*;

public class RadioGUIgrid extends JFrame{

	JPanel framePanel = new JPanel();

	JLabel band = new JLabel("Band:");
	JButton fm = new JButton("FM");
	JButton mw = new JButton("mw");
	JButton lw = new JButton("lw");
	JButton scan = new JButton("Scan");

	public RadioGUIgrid(){

		framePanel.setLayout(new GridLayout(3,3));

		framePanel.add(band);
		framePanel.add(fm);
		framePanel.add(mw);
		framePanel.add(lw);
		framePanel.add(scan);

		add(framePanel);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Radio");
		setSize(300,120);
		setVisible(true);
	}

	public static void main(String[] args) {

		RadioGUIgrid gui = new RadioGUIgrid();

	}

}
