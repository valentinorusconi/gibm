import java.awt.*;
import javax.swing.*;

public class paint extends JFrame{

	paint(){

		setTitle("Paint");
		setSize(300,300);
		setVisible(true);


	}

	public void paint(Graphics g){
		Graphics2D ga = (Graphics2D)g;
		ga.setPaint(Color.red);
		ga.fillRect(0, 0, getWidth(), getHeight());

		ga.setPaint(Color.white);
		ga.fillRect(getWidth()-150, getHeight()-200, 50, 150);
		ga.fillRect(getWidth()-200, getHeight()-150, 150, 50);
	}

	public static void main(String[] args) {
		paint g = new paint();
	}

}
