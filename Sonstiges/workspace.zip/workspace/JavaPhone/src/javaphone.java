import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class javaphone extends JFrame implements ActionListener {

	public javaphone(){

		//--- Inhalt Frame ----------------------------------------

			//Definiere linkes Panel in Frame
			JPanel leftFramePanel = new JPanel();
			leftFramePanel.setLayout(new BorderLayout(10,10));
			add(leftFramePanel,BorderLayout.WEST);

			//Definiere rechtes Panel in Frame
			JPanel rightFramePanel = new JPanel();
			rightFramePanel.setLayout(new BorderLayout(10,10));
			add(rightFramePanel,BorderLayout.CENTER);

		//--- Ende Inhalt Frame -----------------------------------

		//--- Inhalt linkes Panel ---------------------------------

			//Definiere JLabel in linkem Panel
			JLabel statusLabel = new JLabel("Ready");

			//Definiere Button in linkem Panel
			JButton bigLeftButton = new JButton("Hook Off");

			//F�ge JLabel und JButton in linkes Panel ein
			leftFramePanel.add(statusLabel,BorderLayout.NORTH);
			leftFramePanel.add(bigLeftButton,BorderLayout.CENTER);

		//--- Ende Inhalt linkes Panel ----------------------------

		//--- Inhalt rechtes Panel --------------------------------

			//Definiere Textfield in rechtem Panel
			JTextField textfield = new JTextField();

			//Definiere Panel f�r Wahltasten im rechten Panel (Wahlpanel)
			JPanel choosePanel = new JPanel();
			choosePanel.setLayout(new GridLayout(4,3,10,10));

			//--- Inhalt Wahlpanel ------------------------------------

				//Definiere Buttons
				JButton button1 = new JButton("1");
				JButton button2 = new JButton("2");
				JButton button3 = new JButton("3");
				JButton button4 = new JButton("4");
				JButton button5 = new JButton("5");
				JButton button6 = new JButton("6");
				JButton button7 = new JButton("7");
				JButton button8 = new JButton("8");
				JButton button9 = new JButton("9");
				JButton button0 = new JButton("0");
				JButton buttonHash = new JButton("#");
				JButton buttonStar = new JButton("*");

				//F�ge Buttons dem WahlPanel hinzu
				choosePanel.add(button1);
				choosePanel.add(button2);
				choosePanel.add(button3);
				choosePanel.add(button4);
				choosePanel.add(button5);
				choosePanel.add(button6);
				choosePanel.add(button7);
				choosePanel.add(button8);
				choosePanel.add(button9);
				choosePanel.add(button0);
				choosePanel.add(buttonHash);
				choosePanel.add(buttonStar);


			//--- Ende Inhalt Wahlpanel -------------------------------

			//F�ge Textfeld und Wahlpanel dem rechten Panel hinzu
			rightFramePanel.add(textfield,BorderLayout.NORTH);
			rightFramePanel.add(choosePanel,BorderLayout.CENTER);

		//--- Ende Inhalt rechtes Panel ---------------------------

		//Definiere Frame (zu Ende wegen korrekter Initialisierung)
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("JavaPhone");
		setSize(600,600);
		setVisible(true);

		//--- Alle Buttons dem ActionListener hinzuf�gen ----------  (Noch nicht vollendet)
		bigLeftButton.addActionListener(this);
		button1.addActionListener(this);
		button2.addActionListener(this);
		button3.addActionListener(this);
		button4.addActionListener(this);
		button5.addActionListener(this);
		button6.addActionListener(this);
		button7.addActionListener(this);
		button8.addActionListener(this);
		button9.addActionListener(this);
		button0.addActionListener(this);
		buttonHash.addActionListener(this);
		buttonStar.addActionListener(this);

	}

	public static void main(String[] args) {

		javaphone jp = new javaphone();

	}

	public void actionPerformed (ActionEvent ae){

        if(ae.getSource() == this.button1){

        }
        else if(ae.getSource() == button2){

        }
        else if (ae.getSource() == button3){

        }
    }

}
