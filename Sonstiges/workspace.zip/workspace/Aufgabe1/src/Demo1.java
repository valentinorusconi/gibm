// Diese Demo soll zeigen, wie BorderLayout und Grid funktioniert.

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Demo1 extends JFrame{

	JLabel toplabel = new JLabel("I'm up in the north");
	JLabel centerlabel = new JLabel("I'm in the center");
	JLabel bottomlabel = new JLabel("I'm down down down");

	JPanel bottompanel = new JPanel();
	JLabel leftlabel = new JLabel("Command 1");
	JLabel rightlabel = new JLabel("Command 2");
	JButton leftbutton = new JButton("Push 1");
	JButton rightbutton = new JButton("Push 2");

	public Demo1() {

		setLayout(new BorderLayout());

		bottompanel.setLayout(new GridLayout(2,2));

		bottompanel.add(leftlabel);
		bottompanel.add(rightlabel);
		bottompanel.add(leftbutton);
		bottompanel.add(rightbutton);

		toplabel.setOpaque(true);
		toplabel.setBackground(Color.white);

		centerlabel.setOpaque(true);
		centerlabel.setBackground(Color.red);

		bottomlabel.setOpaque(true);
		bottomlabel.setBackground(Color.green);

		add(toplabel,BorderLayout.NORTH);
		add(centerlabel,BorderLayout.CENTER);
		add(bottompanel,BorderLayout.SOUTH);

		setDefaultCloseOperation(EXIT_ON_CLOSE);

		setTitle("Layout 1st Demo");
		setSize(300,600);
		setVisible(true);

	}

	public static void main(String[] args) {

		Demo1 d = new Demo1();

	}

}
